import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class uasScreen extends StatefulWidget {
  const uasScreen({Key? key}) : super(key: key);

  @override
  State<uasScreen> createState() => _uasScreenState();
}

class _uasScreenState extends State<uasScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 50, 167, 126),
        title: const Text('Profile'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration:
                  BoxDecoration(color: Color.fromARGB(255, 50, 167, 126)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.transparent,
                    child: Icon(
                      Icons.face_6_sharp,
                      size: 25,
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.all(3.0),
                            child: Text(
                              "Guest",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(3.0),
                            child: Text(
                              "@user-xkjfksj",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(3.0),
                            child: Text(
                              "xxx@gmail.com",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      )),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
              child: TextButton(
                onPressed: () {},
                child: Text('RESERVE'),
                style: TextButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 43, 103, 82),
                    foregroundColor: Colors.white,
                    shape: const BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    textStyle: TextStyle(fontWeight: FontWeight.bold),
                    elevation: 3),
              ),
            ),
            Divider(),
            ListTile(
              onTap: () {},
              leading: Icon(Icons.home_filled),
              title: Text("Home"),
              trailing: Icon(Icons.keyboard_arrow_right_sharp),
            ),
            ListTile(
              onTap: () {},
              leading: Icon(Icons.menu_book_rounded),
              title: Text("Menu"),
              trailing: Icon(Icons.keyboard_arrow_right_sharp),
            ),
            ListTile(
              onTap: () {},
              leading: Icon(Icons.question_mark_sharp),
              title: Text("About Us"),
              trailing: Icon(Icons.keyboard_arrow_right_sharp),
            ),
            ListTile(
              onTap: () {},
              leading: Icon(Icons.contact_page),
              title: Text("Contact"),
              trailing: Icon(Icons.keyboard_arrow_right_sharp),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {},
          child: Icon(Icons.menu_book_rounded),
          backgroundColor: Colors.white,
          foregroundColor: Color.fromARGB(255, 43, 103, 82),
          shape: RoundedRectangleBorder(
              side:
                  BorderSide(width: 3, color: Color.fromARGB(255, 43, 103, 82)),
              borderRadius: BorderRadius.circular(100))),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        //bottom navigation bar on scaffold
        color: Color.fromARGB(255, 50, 167, 126),
        shape: CircularNotchedRectangle(), //shape of notch
        notchMargin:
            5, //notche margin between floating button and bottom appbar
        child: Row(
          //children inside bottom appbar
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: Icon(
                Icons.home_filled,
                color: Colors.white,
              ),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(
                Icons.restaurant,
                color: Colors.white,
              ),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(
                Icons.question_answer,
                color: Colors.white,
              ),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(
                Icons.person_2,
                color: Colors.white,
              ),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: EdgeInsets.all(15.0),
            child: CircleAvatar(
              backgroundColor: Color.fromARGB(255, 50, 167, 126),
              child: Icon(Icons.person_2_sharp, size: 60),
              radius: 50,
            ),
          ),
          Center(
            child: Text(
              'Guest',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: Color.fromARGB(255, 44, 86, 72)),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(30.0),
            child: SizedBox(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(15.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Username',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Color.fromRGBO(27, 86, 81, 1)),
                        ),
                        Text('@user-xxgga-ewgs')
                      ],
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.all(15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Email',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Color.fromRGBO(27, 86, 81, 1)),
                          ),
                          Text('xxxxx@gmail.com')
                        ],
                      )),
                  Padding(
                      padding: EdgeInsets.all(15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Telp',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Color.fromRGBO(27, 86, 81, 1)),
                          ),
                          Text('+62 3985-2451-2124')
                        ],
                      )),
                  Padding(
                      padding: EdgeInsets.all(15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Location',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Color.fromRGBO(27, 86, 81, 1)),
                          ),
                          Text('Medan, Indonesia')
                        ],
                      ))
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
